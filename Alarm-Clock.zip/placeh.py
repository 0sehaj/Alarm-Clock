#text holder to go inside the hours min and sec text boxes
"""
def clear_entry(event, entry):
  entry.delete(0, END)

htext.pack()
placeholder_text = 'hh'
htext.insert(0, placeholder_text)

htext.bind("<Button-1>", lambda event: clear_entry(event, entry))

#

htext.pack()
htext.insert(0, 'hh')
htext.configure(state=DISABLED)
def on_click(event):
    htext.configure(state=NORMAL)
    htext.delete(0, END)
    htext.unbind('<Button-1>', on_click_id)

on_click_id = htext.bind('<Button-1>', on_click)
"""